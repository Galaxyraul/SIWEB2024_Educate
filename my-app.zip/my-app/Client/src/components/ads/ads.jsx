import React from 'react';
import './ads.css';

const VerticalAd = () => {
  return (
    <div className="vertical-ad">
      <img src="http://localhost:5000/resources/images/ad.png" alt="Ad" />
    </div>
  );
};

export default VerticalAd;